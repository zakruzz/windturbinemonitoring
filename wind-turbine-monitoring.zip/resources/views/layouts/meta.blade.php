<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">

<title>@yield('title') - Wind Turbine Monitoring</title>

<meta name="robots" content="noindex, nofollow">

<link rel="shortcut icon" href="https://www.its.ac.id/wp-content/uploads/2020/07/Lambang-ITS-2-300x300.png">
<link rel="icon" type="image/png" sizes="192x192" href="https://www.its.ac.id/wp-content/uploads/2020/07/Lambang-ITS-2-300x300.png">
<link rel="apple-touch-icon" sizes="180x180" href="https://www.its.ac.id/wp-content/uploads/2020/07/Lambang-ITS-2-300x300.png">
