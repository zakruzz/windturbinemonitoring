<footer id="page-footer">
    <div class="content py-3">
        <div class="row fs-sm">
            <div class="col-sm-6 order-sm-2 py-1 text-center text-sm-end">
                Crafted with <i class="fa fa-heart text-danger"></i>
            </div>
            <div class="col-sm-6 order-sm-1 py-1 text-center text-sm-start">
                Copyright &copy; <span data-toggle="year-copy"></span>
            </div>
        </div>
    </div>
</footer>
