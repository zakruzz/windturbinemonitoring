<!doctype html>
<html lang="en">
<head>

    @include('layouts.meta')

    @include('layouts.style')

</head>
<body>

@yield('modal')

@yield('content')

@include('layouts.script')

</body>
</html>
